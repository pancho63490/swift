//
//  supermarket2App.swift
//  supermarket2
//
//  Created by Frank Perez on 24/07/24.
//

import SwiftUI

@main
struct supermarket2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
