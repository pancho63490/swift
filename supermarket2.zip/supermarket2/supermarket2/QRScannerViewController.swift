import AVFoundation
import UIKit

class QRScannerViewController: UIViewController, AVCaptureMetadataOutputObjectsDelegate {
    var captureSession: AVCaptureSession!
    var previewLayer: AVCaptureVideoPreviewLayer!
    var detectionRectangle: UIView!

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.black
        captureSession = AVCaptureSession()
        checkCameraPermission()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        previewLayer?.frame = view.layer.bounds
        updateDetectionRectangle()
    }

    func checkCameraPermission() {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            setupCamera()
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video) { granted in
                if granted {
                    DispatchQueue.main.async {
                        self.setupCamera()
                    }
                }
            }
        case .denied, .restricted:
            presentCameraSettings()
        @unknown default:
            fatalError("Unknown authorization status")
        }
    }

    func setupCamera() {
        guard let videoCaptureDevice = AVCaptureDevice.default(for: .video) else { return }
        let videoInput: AVCaptureDeviceInput

        do {
            videoInput = try AVCaptureDeviceInput(device: videoCaptureDevice)
        } catch {
            return
        }

        if captureSession.canAddInput(videoInput) {
            captureSession.addInput(videoInput)
        } else {
            return
        }

        let metadataOutput = AVCaptureMetadataOutput()

        if captureSession.canAddOutput(metadataOutput) {
            captureSession.addOutput(metadataOutput)
            metadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
            metadataOutput.metadataObjectTypes = [.qr, .ean8, .ean13, .pdf417]

            // Define el área de interés más alto y menos ancho en el centro de la pantalla
            let detectionArea = CGRect(x: 0.4, y: 0.2, width: 0.2, height: 0.6)
            metadataOutput.rectOfInterest = detectionArea

            // Crea y añade el rectángulo de detección
            detectionRectangle = UIView()
            detectionRectangle.layer.borderColor = UIColor.green.cgColor
            detectionRectangle.layer.borderWidth = 2
            view.addSubview(detectionRectangle)

            previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
            previewLayer.frame = view.layer.bounds
            previewLayer.videoGravity = .resizeAspectFill
            view.layer.addSublayer(previewLayer)

            view.bringSubviewToFront(detectionRectangle)

            captureSession.startRunning()
            updateDetectionRectangle()
        } else {
            return
        }
    }

    func updateDetectionRectangle() {
        if let previewLayer = previewLayer {
            // Ajusta el área de interés para que sea más alto y menos ancho
            let rectConverted = previewLayer.layerRectConverted(fromMetadataOutputRect: CGRect(x: 0.4, y: 0.2, width: 0.2, height: 0.6))
            detectionRectangle.frame = rectConverted
        }
    }

    func presentCameraSettings() {
        let alertController = UIAlertController(title: "Permiso de Cámara",
                                                message: "La cámara está deshabilitada. Por favor, habilítela en la configuración.",
                                                preferredStyle: .alert)

        alertController.addAction(UIAlertAction(title: "Cancelar", style: .cancel, handler: nil))
        alertController.addAction(UIAlertAction(title: "Abrir Configuración", style: .default) { _ in
            guard let settingsUrl = URL(string: UIApplication.openSettingsURLString) else { return }
            if UIApplication.shared.canOpenURL(settingsUrl) {
                UIApplication.shared.open(settingsUrl, completionHandler: nil)
            }
        })

        present(alertController, animated: true, completion: nil)
    }

    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        if let metadataObject = metadataObjects.first {
            guard let readableObject = metadataObject as? AVMetadataMachineReadableCodeObject else { return }
            guard let stringValue = readableObject.stringValue else { return }
            AudioServicesPlaySystemSound(SystemSoundID(kSystemSoundID_Vibrate))

            captureSession.stopRunning()

            let alertController = UIAlertController(title: "Código Detectado", message: stringValue, preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "OK", style: .default) { _ in
                self.captureSession.startRunning()
            })
            present(alertController, animated: true)
        }
    }

    override var prefersStatusBarHidden: Bool {
        return true
    }

    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .all
    }
}
